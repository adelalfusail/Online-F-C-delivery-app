package com.example.adel.habayessinresturant;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private static final String NAME ="";
    private static final int PICK_CONTACT = 1;
    static final int PICK_CONTACT_REQUEST = 1;
    shareperef shareperefclass=shareperef.getInstance(this);
    private RadioGroup radiogenderGroup;
    private RadioButton radiogenderButton;
    ImageButton contact;
    EditText number1;
    Dialog myDialog;
    CheckBox payCash;
    EditText cardNumber;

    Button learn_emergncy;
    boolean statusOfPayment;
    private static final int CONTACT_PICKER_RESULT = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final Intent home=new Intent(LoginActivity.this,HomeActivity.class);
        if(shareperefclass.GetLoginState())
        {
            startActivity(home);
            LoginActivity.this.finish();
        }

        final Intent learn=new Intent(LoginActivity.this,how_to_use.class);
        final EditText username=(EditText)findViewById(R.id.username);
        final EditText age=(EditText)findViewById(R.id.age);

        radiogenderGroup = (RadioGroup) findViewById(R.id.radiogender);
        myDialog = new Dialog(this);
       payCash=findViewById(R.id.checkPay);
        Button signup=(Button)findViewById(R.id.SingUp);
      cardNumber=findViewById(R.id.CardNumber);
        contact=(ImageButton)findViewById(R.id.contact);
        number1=(EditText)findViewById(R.id.number1);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
payCash.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(payCash.isChecked()){
            cardNumber.setBackgroundColor(Color.parseColor("#76080a09"));
            cardNumber.setEnabled(false);
            statusOfPayment=false;
        }if(!payCash.isChecked()){
            cardNumber.setBackgroundColor(Color.WHITE);
            cardNumber.setEnabled(true);
            statusOfPayment=true;
        }
    }
});

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!isEmpty(username) && !isEmpty(age)&& !isEmpty(number1) ) {

                    int selectedId = radiogenderGroup.getCheckedRadioButtonId();
                    // find the radiobutton by returned id
                    radiogenderButton = (RadioButton) findViewById(selectedId);

                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("name", username.getText().toString()); //InputString: from the EditText
                    editor.putString("age", age.getText().toString());
                    editor.putString("gender", radiogenderButton.getText().toString());
                    editor.putString("NUMBER", number1.getText().toString());
                    editor.putBoolean("statusOfPayment",statusOfPayment);
                    editor.commit();

                    Toast.makeText(LoginActivity.this, "Registration is Done", Toast.LENGTH_SHORT).show();
                    shareperefclass.SaveLoginState(true);
                    startActivity(home);
                    finish();


                } else {
                    if (isEmpty(username)) {
                        username.setError("Please enter your name");
                    }

                    if (isEmpty(age)) {
                        age.setError("Please enter your age");
                    }
                    if(isEmpty(number1)){
                        number1.setError("please enter your number");
                    }
                }

            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                //startActivityForResult(intent,PICK_CONTACT);
                Intent pickContactIntent = new Intent(Intent.ACTION_PICK, Uri.parse("content://contacts"));
                pickContactIntent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE); // Show user only contacts w/ phone numbers
                startActivityForResult(pickContactIntent, PICK_CONTACT_REQUEST);


            }
        });


    }

    boolean isEmpty(EditText text){
        CharSequence str=text.getText().toString();
        return TextUtils.isEmpty(str);
    }



    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        try{
            if (requestCode == PICK_CONTACT_REQUEST) {
                // Make sure the request was successful
                if (resultCode == RESULT_OK) {
                    // Get the URI that points to the selected contact
                    Uri contactUri = data.getData();
                    // We only need the NUMBER column, because there will be only one row in the result
                    String[] projection = {ContactsContract.CommonDataKinds.Phone.NUMBER};

                    // Perform the query on the contact to get the NUMBER column
                    // We don't need a selection or sort order (there's only one result for the given URI)
                    // CAUTION: The query() method should be called from a separate thread to avoid blocking
                    // your app's UI thread. (For simplicity of the sample, this code doesn't do that.)
                    // Consider using CursorLoader to perform the query.
                    Cursor cursor = getContentResolver()
                            .query(contactUri, projection, null, null, null);
                    cursor.moveToFirst();

                    // Retrieve the phone number from the NUMBER column
                    int column = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                    String number = cursor.getString(column);
                    number1.setText(number);
                    Log.e("messege", "number="+number);
                    // Do something with the phone number...
                }
            }


        } catch (Exception e) {
            Log.e("messege", "Error reading contacts", e);
        }
    }
}
