package com.example.adel.habayessinresturant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CoffeActivity extends AppCompatActivity {
    private int chocoQuantity = 0, amrcinQuantity = 0, espraQuantity = 0, capputQuantity = 0, total;
    TextView chocoQuantityNumb;
    TextView amrcinQuantityNumb;
    TextView espraQuantityNumb;
    TextView capputQuantityNumb;
    TextView totalPrice;
    Button getOrder;
    shareperef shareperefclass = shareperef.getInstance(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffe);
        chocoQuantityNumb = findViewById(R.id.quantity_choco);
        amrcinQuantityNumb = findViewById(R.id.quantity_Americana);
        espraQuantityNumb = findViewById(R.id.quantity_Espreso);
        capputQuantityNumb = findViewById(R.id.quantity_cappuccino);
        totalPrice = findViewById(R.id.totalPrice);
        getOrder = findViewById(R.id.orderButton);

        getOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(CoffeActivity.this);
                SharedPreferences.Editor editor = prefs.edit();
                String coffeeOrder = amrcinQuantity + ":" + capputQuantity + ":" + espraQuantity + ":" + chocoQuantity + ":" + total;
                editor.putString("coffeeOrder", coffeeOrder);

                editor.commit();
                shareperefclass.SaveOrderState(true);
                Toast.makeText(CoffeActivity.this, "Your order is ready ", Toast.LENGTH_LONG).show();
                Intent home = new Intent(CoffeActivity.this, HomeActivity.class);
                startActivity(home);
                finish();
            }
        });
    }

    public void decrementCohoco(View view) {
        if (chocoQuantity > 0) {
            chocoQuantity -= 1;
            chocoQuantityNumb.setText("" + chocoQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "0 is lowest Quantity", Toast.LENGTH_SHORT).show();
    }

    public void incrementChoco(View view) {
        if (chocoQuantity < 100) {
            chocoQuantity += 1;
            chocoQuantityNumb.setText("" + chocoQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "99 is highest Quantity", Toast.LENGTH_SHORT).show();
    }


    public void incrementEspres(View view) {
        if (espraQuantity < 100) {
            espraQuantity += 1;
            espraQuantityNumb.setText("" + espraQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "99 is highest Quantity", Toast.LENGTH_SHORT).show();

    }

    public void decrementEspres(View view) {
        if (espraQuantity > 0) {
            espraQuantity -= 1;
            espraQuantityNumb.setText("" + espraQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "0 is lowest Quantity", Toast.LENGTH_SHORT).show();
    }

    public void incrementCappuc(View view) {
        if (capputQuantity < 100) {
            capputQuantity += 1;
            capputQuantityNumb.setText("" + capputQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "99 is highest Quantity", Toast.LENGTH_SHORT).show();

    }

    public void decrementCappuc(View view) {
        if (capputQuantity > 0) {
            capputQuantity -= 1;
            capputQuantityNumb.setText("" + capputQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "0 is lowest Quantity", Toast.LENGTH_SHORT).show();

    }

    public void incrementAmerciana(View view) {
        if (amrcinQuantity < 100) {
            amrcinQuantity += 1;
            amrcinQuantityNumb.setText("" + amrcinQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "99 is highest Quantity", Toast.LENGTH_SHORT).show();
    }

    public void decrementAmerciana(View view) {
        if (amrcinQuantity > 0) {
            amrcinQuantity -= 1;
            amrcinQuantityNumb.setText("" + amrcinQuantity);
            refreshTotal();

        } else
            Toast.makeText(this, "0 is lowest Quantity", Toast.LENGTH_SHORT).show();
    }

    private void refreshTotal() {
        total = amrcinQuantity * 4 + chocoQuantity * 2 + capputQuantity * 6 + espraQuantity * 3;
        totalPrice.setText(total + "$");
    }
}
