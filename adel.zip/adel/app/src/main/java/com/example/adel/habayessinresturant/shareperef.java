package com.example.adel.habayessinresturant;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class shareperef {
    public static final String mLoginDataString="LoginState";
    public static final String mOrderDataString="OrderState";
    Context context;
    SharedPreferences sharedPreferences;
    static shareperef instance;

    public shareperef (Context context)
    {
        this.context=context;
    }
    public static shareperef getInstance(Context context)
    {
        if(instance==null)
            instance=new shareperef(context);

        return instance;
    }
    public  void SaveLoginState(boolean data)
    {
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putBoolean(mLoginDataString,data);
        editor.commit();

    }
    public  void SaveOrderState(boolean data)
    {
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putBoolean(mOrderDataString,data);
        editor.commit();

    }
    public  boolean GetLoginState()
    {
        boolean state=false;
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        state=sharedPreferences.getBoolean(mLoginDataString,false);
        return state;
    }
    public  boolean GetOrderState()
    {
        boolean state=false;
        sharedPreferences= PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        state=sharedPreferences.getBoolean(mOrderDataString,false);
        return state;
    }

}