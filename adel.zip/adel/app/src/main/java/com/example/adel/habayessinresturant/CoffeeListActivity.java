package com.example.adel.habayessinresturant;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class CoffeeListActivity extends AppCompatActivity {
    Dialog myDialog;
     RelativeLayout close;
     TextView txtclose;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffee_list);
        myDialog = new Dialog(this);
        close=findViewById(R.id.cloaeCoffe);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                myDialog.setContentView(R.layout.emrgency_learn);
                txtclose =(TextView) myDialog.findViewById(R.id.close);
                txtclose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDialog.dismiss();
                    }
                });
                myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                myDialog.show();
            }
        });

    }

    public void stockCoffe(View view) {
        Intent coffeeOrder = new Intent(CoffeeListActivity.this, CoffeActivity.class);
        startActivity(coffeeOrder);
finish();

    }

    public void colseCoffee(View view) {




        }
    }


