package com.example.adel.habayessinresturant;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
TextView numberChoco;
    TextView numberAmaric;
    TextView numberCapput;
    TextView numberEsprito;
    TextView totalPrice;
    String coffeePref;
    Button learnMore;
    String[] splitCoffeePref;
    shareperef shareperefclass=shareperef.getInstance(this);
    Dialog myDialog;
    TextView Name;
    TextView Gender;
    TextView Phone;
    TextView Payment;
    Button logOut;
    boolean status;
double totalNumber=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        numberChoco=findViewById(R.id.numberchocolate);
        numberAmaric=findViewById(R.id.numberAmrieno);
        numberEsprito=findViewById(R.id.numberEspresso);
        numberCapput=findViewById(R.id.numbercappuccino);
        totalPrice=findViewById(R.id.totalFullPrice);
        learnMore=findViewById(R.id.learnMore);
        Name=findViewById(R.id.Name);
        Gender=findViewById(R.id.Gender);
        Phone=findViewById(R.id.Phone);
        logOut= findViewById(R.id.logout);
        Payment=findViewById(R.id.payment);
        myDialog = new Dialog(this);
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareperefclass.SaveLoginState(false);
                Intent out = new Intent(HomeActivity.this,LoginActivity.class);
                startActivity(out);
                finish();
            }
        });
        learnMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            Intent learn=new Intent(HomeActivity.this,how_to_use.class);
startActivity(learn);
            }
        });
        if(shareperefclass.GetOrderState())
        {
            Name.setText(prefs.getString("name",null));
            Gender.setText(prefs.getString("gender",null));
            Phone.setText(prefs.getString("NUMBER",null));
            status=prefs.getBoolean("statusOfPayment",status);
            if(status){
                Payment.setText("By vise card");
            }
            else{
                Payment.setText("Cash when order received");
            }
            coffeePref=prefs.getString("coffeeOrder",null);
            splitCoffeePref=coffeePref.split(":");
            numberAmaric.setText(splitCoffeePref[0]);
            numberCapput.setText(splitCoffeePref[1]);
            numberEsprito.setText(splitCoffeePref[2]);
            numberChoco.setText(splitCoffeePref[3]);
            totalNumber=Double.parseDouble(splitCoffeePref[4]);
            totalPrice.setText("$"+splitCoffeePref[4]);
            shareperefclass.SaveOrderState(false);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    public void fastFood(View view) {
    }

    public void coffe(View view) {
        Intent coffee = new Intent(HomeActivity.this, CoffeeListActivity.class);
        startActivity(coffee);

    }

    public void dicount(View view) {
        double half=0.5;
        double discount=  totalNumber*half;
        totalPrice.setText("$"+discount);
    }
}
