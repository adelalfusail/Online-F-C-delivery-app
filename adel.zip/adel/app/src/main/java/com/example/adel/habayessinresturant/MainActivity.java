package com.example.adel.habayessinresturant;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    shareperef shareperefclass=shareperef.getInstance(this);

 ImageView icon;
 TextView welcomeMessge;
 Animation fromTop , fromButtom ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        icon=findViewById(R.id.splashicon);
        welcomeMessge=findViewById(R.id.titel);

        fromTop= AnimationUtils.loadAnimation(this,R.anim.fromtop);
        fromButtom= AnimationUtils.loadAnimation(this,R.anim.frombottom);

        fromButtom.setDuration(2000);
        fromTop.setDuration(2000);

        icon.setAnimation(fromTop);
        welcomeMessge.setAnimation(fromButtom);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent home= new Intent(MainActivity.this,LoginActivity.class);
                startActivity(home);
                finish();
            }
        },2*1000);

    }



}

